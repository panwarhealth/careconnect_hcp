(function($) {
    
    $(document).ready(function(){  
	var maxField = $('#field_khh7w'); // Source field (sets the max)
    var targetField = $('#field_9962s'); // Target field (gets validated)
    
    // Update max attribute when source field changes
    maxField.on('change keyup', function() {
        var maxValue = parseFloat($(this).val()) || 0;
        targetField.attr('max', maxValue);
        console.log(maxValue);

        // Validate current value
        var currentValue = parseFloat(targetField.val()) || 0;
        if (currentValue > maxValue) {
            targetField.val(maxValue);
            alert('Maximum value is ' + maxValue);
        }
    });
    
    // Validate on target field change
    targetField.on('change', function() {
        var maxValue = parseFloat(maxField.val()) || 0;
        var currentValue = parseFloat($(this).val()) || 0;
        
        if (currentValue > maxValue) {
            $(this).val(maxValue);
            alert('Value cannot exceed ' + maxValue);
        }
    });
    
    // Set initial max value
    maxField.trigger('change');

        if($('.sidenav').length && $('.tab-content').length) {
            
				var $root = $('html, body'),
					tabElem = $('.sidenav'),
					targetPos = tabElem.offset().top,
					tabContents = $('.tab-content');

				tabElem.find('a').click(function(){
					let adtnlspacer = tabElem.offset().top - $(document).scrollTop();
					tabElem.find('a').removeClass('active');
					$(this).addClass('active');
					$root.animate({
						scrollTop: $($(this).attr('href')).offset().top - adtnlspacer
					});
				});

				$.event.add(window, "scroll", function () {
					
					let adtnlspacer = tabElem.offset().top - $(document).scrollTop();
						targetPos = tabElem.offset().top - adtnlspacer;
						tabContents.each(function(){
							let tabPos = $(this).offset().top - adtnlspacer;
							if( (targetPos > (tabPos - ($(this).height()/2)) && targetPos < (tabPos + $(this).height())) && tabElem.offset().top	> targetPos ){
							    //console.log(targetPos);
								tabElem.find('a').removeClass('active');
								tabElem.find('a[href*="#'+ $(this).attr('id') +'"]').addClass('active');
							}
						});
				});
        }
        
        const formID = '#quizForm1';
        if($(formID).length){
            
            $('input[name="question1"], input[name="question17"], input[name="question33"], input[name="question49"]').on('change', function() {
                
               let wrapper = $(this).closest('.qsm-question-wrapper');

                let interval = setInterval(function () {
                    let target = wrapper.find('.quick-question-res-p');
                    if (target.length) {
                        clearInterval(interval); // Stop once found
                        if(target.hasClass('qsm-correct-answer-info')){
                            target.html( wrapper.find('.question-response .correct').html() );
                        }
                        if(target.hasClass('qsm-incorrect-answer-info')){
                            target.html( wrapper.find('.question-response .incorrect').html() );
                        }
                    }
                }, 200);
                // Check if all 4 have a selected value
                /*if (
                    $('input[name="question1"]:checked').val() &&
                    $('input[name="question17"]:checked').val() &&
                    $('input[name="question33"]:checked').val() &&
                    $('input[name="question49"]:checked').val()
                ) {
                    // Submit the form (adjust selector if needed)
                   // $(this).closest('form').submit();
                   //$('.qsm-btn.qsm-submit-btn.qmn_btn').trigger('click');
                }*/
            });
            
        }
        
        
        /** start of sticky JS widget **/
        if ($('.js-sticky-widget').length) {
        var stickyEl = new Sticksy.initializeAll('.js-sticky-widget', {
    		topSpacing: 60,
    	});
    	
        stickyEl.onStateChanged = function (state) {
            if(state === 'fixed') {
                stickyEl.nodeRef.classList.add('widget--sticky')
            } else {
                stickyEl.nodeRef.classList.remove('widget--sticky')
            }
        }
        /** end of sticky JS widget **/
        
    }
    
        if($('body.logged-in').length) {
            $('*').removeClass('logged_in_users_only');
            //console.log("cleared");
        }
    
    // survey form
    const $otherCheckboxes = $("input[name='question_17_33']:last, input[name='question_17_49']:last, input[name='question_17_97']:last");
    if ($otherCheckboxes.length > 0) {
        function handleOtherFieldVisibility() {
            $otherCheckboxes.each(function() {
                const $this = $(this);
                const $elementToToggle = $this.closest('li.wpProQuiz_listItem').next();
                if ($this.is(':checked')) {
                    $elementToToggle.show();
                } else {
                    $elementToToggle.hide();
                }
                //console.log($this.val(),$this.is(':checked'))
            });
        }

        $otherCheckboxes.on('change', handleOtherFieldVisibility);
        
        setTimeout(function() {
            handleOtherFieldVisibility();
        }, 3000);
    }
    
    
    if($('img.expandable').length){
        $('img.expandable').on('click', function() {
            let src = $(this).attr('src');
            let overlay = $(`<div class="w-full h-full fixed inset-0 p-lg bg-black bg-opacity-50 z-50 overflow-y-auto">
                    <img class="w-full mb-0" src="${src}">
                </div>`);
                overlay.appendTo('#app');
            overlay.click(function(){
                $(this).remove();
            });
        });
    }
    
    // --- setup interactive map ---
    const $tooltip = $('#diagram-tooltip');
    const $map = $('map[name="cycle-map"]');
    const $image = $('#interactive-diagram');
    const $container = $image.parent(); 
    const originalWidth = 2560; // The natural width of the source image

    if ($map.length === 0 || $image.length === 0) {
        console.error("Required elements (map or image) not found.");
        return;
    }

    // --- responsive ---
    function resizeMap() {
        const currentWidth = $image.width();
        const ratio = currentWidth / originalWidth;
        $map.find('area').each(function() {
            const $area = $(this);
            if (!$area.data('original-coords')) {
                $area.data('original-coords', $area.attr('coords'));
            }
            const originalCoords = $area.data('original-coords').split(',');
            let newCoords = [];
            originalCoords.forEach(function(coord) {
                newCoords.push(Math.round(parseInt(coord.trim()) * ratio));
            });
            $area.attr('coords', newCoords.join(','));
            });
    }
    
    $image.on('load', resizeMap).each(function() {
        if (this.complete) $(this).trigger('load');
    });
    $(window).on('resize', resizeMap);
        const $areas = $map.find('area');
        const isTouchDevice = 'ontouchstart' in window || navigator.maxTouchPoints > 0;

        if (isTouchDevice) {
                const $mobileDisplay = $('#mobile-tooltip-display');
                $tooltip.remove(); 
                $mobileDisplay.removeClass('hidden');

                $areas.on('click', function(e) {
                    e.preventDefault();
                    const key = $(this).attr('href').replace('#', '');
                    const contentId = '#pop-' + key;
                    const $contentElement = $(contentId);

                    if ($contentElement.length > 0) {
                        const text = $contentElement.html();
                        $mobileDisplay.html(text);
                    }
                });

        } else {
            $areas.on('click', function(e) {
                e.preventDefault();
            });
            
            $areas.on('mouseenter', function(e) {
                    const key = $(this).attr('href').replace('#', '');
                    const contentId = '#pop-' + key;
                    const $contentElement = $(contentId);
                    if ($contentElement.length > 0) {
                        const text = $contentElement.html();
                        $tooltip.html(text).show();
                    }
            }).on('mouseleave', function() {
                $tooltip.hide();
            }).on('mousemove', function(e) {
                    const containerOffset = $container.offset();
                    const containerWidth = $container.width();
                    const tooltipWidth = $tooltip.outerWidth();
                    
                    let x = e.pageX - containerOffset.left + 15;
                    const y = e.pageY - containerOffset.top + 15;

                    if (x + tooltipWidth > containerWidth) {
                        x = e.pageX - containerOffset.left - tooltipWidth - 15;
                    }

                    $tooltip.css({ top: y + 'px', left: x + 'px' });
            });
        }
        
    
	});
	
	
    $(document).ready(function($) {
      const isUserLoggedIn = $('body').hasClass('logged-in') ? true : false;
      const hasDismissedPopup = sessionStorage.getItem('popupDismissed');
      
      const popupOverlay = $('#register-popup');
    
      if (isUserLoggedIn || hasDismissedPopup) {
        return; 
      }
      
      function showPopup() {
        popupOverlay.removeClass('hidden');
      }
    
      function hidePopup() {
        popupOverlay.addClass('hidden');
        sessionStorage.setItem('popupDismissed', 'true');
      }
      
      setTimeout(showPopup, 2000); 
    
      $('#close-popup').on('click', hidePopup);
      popupOverlay.on('click', function(event) {
        if (event.target.id === 'register-popup') {
          hidePopup();
        }
      });

    });
}(jQuery));

document.addEventListener('DOMContentLoaded', (event) => {
    if(jQuery('body.logged-in').length) {
        jQuery('*').removeClass('logged_in_users_only');
        console.log("cleared");
        
    }
    
});
